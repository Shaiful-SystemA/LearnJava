#Practices
<table cellpadding="2" cellspacing="2" border="1">
            <tbody><tr>
              <td><b>Release date<br>(Time: 10am)</b></td> 
              <td><b>Topic</b></td> <td><b>#</b></td> 
              <td><b>Title</b></td>
              <td><b>Status</b></td>
            </tr>
            <!-- Week 1 -->
            <tr>
              <td rowspan="3">12 January,<br>Tuesday</td>
              <td rowspan="3">Java Basics</td> 
              <td>01</td>
              <td>Sum of Positive Integers</td> 
               
              
              <td>Completed</td>
            </tr>
            <tr>
              <td>02</td>
              <td>Distance Conversion</td> 
               
              
              <td>Completed</td>
            </tr>
            <tr>
              <td>03</td>
              <td>Weights of Washers</td> 
               
               
              <td>Completed</td>
            </tr>
            <!-- Week 2 -->
            <tr>
              <td rowspan="9">19 January,<br>Tuesday</td>
              <td rowspan="3">Arrays</td> 
              <td>04</td>
              <td>Basic Statistics</td> 
               
               
              <td>Completed</td>
            </tr>
            <tr>
              <td>05</td>
              <td>Missing Digits</td> 
               
               
              <td>Completed</td>
            </tr>
            <tr>
              <td>06</td>
              <td>Row and Column Sums</td> 
               
               
              <td>Completed</td>
            </tr>
            <tr>
              <td rowspan="6">OOP Part 1: User Mode</td> 
              <td>07</td>
              <td>Reading Techniques</td> 
               
               
              <td>Completed</td>
            </tr>
            <tr>
              <td>08</td>
              <td>Vaccination</td> 
               
               
              <td>Completed</td>
            </tr>
            <tr>
              <td>09</td>
              <td>Vaccination Version 2</td> 
               
               
              <td>Completed</td>
            </tr>
            <tr>
              <td>10</td>
              <td>One-Line Pretty Printer</td> 
               
               
              <td>Completed</td>
            </tr>
            <tr>
              <td>11</td>
              <td>Area of Circle Enclosing a Square</td> 
               
               
              <td>Completed</td>
            </tr>
            <tr>
              <td>12</td>
              <td>Triangle Centroid</td> 
               
               
              <td>Completed</td>
            </tr>
            <!-- Week 3 -->
            <tr>
              <td rowspan="2">26 January,<br>Tuesday</td>
              <td rowspan="2">OOP Part 2: Designer Mode</td> 
              <td>13</td>
              <td>Ball with centre<br>
                  (Submit CentredBall.java and TestCentredBall.java)</font></td> 
               
               
              <td>Completed</td>
            </tr>
            <tr>
              <td>14</td>
              <td>Fraction<br> 
                  (Submit only Fraction.java)</font></td> 
               
               
              <td>Completed</td>
            </tr>
            <!-- Week 4 -->
            <tr>
              <td rowspan="7">2 February,<br>Tuesday</td>
              <td rowspan="3">Vector and ArrayList</td> 
              <td>15</td>
              <td>Missing Digits Version 2</td> 
               
               
              <td>Completed</td>
            </tr>
            <tr>
              <td>16</td>
              <td>Set Containment<br>
                  (Submit Set.java and TestSet.java)</font></td> 
               
               
              <td>Completed</td>
            </tr>
            <tr>
              <td>17</td>
              <td>Nearest Points</td> 
               
               
              <td>Completed</td>
            </tr>
            <tr>
              <td rowspan="3">OOP</td> 
              <td>18</td>
              <td>Overlapping Rectangles Version 2<br>
                  (Submit MyRect.java and OverlapRectanglesV2.java)</font></td> 
               
               
              <td>Completed</td>
            </tr>
            <tr>
              <td>19</td>
              <td>Overlapping Rectangles Version 3<br> 
                  (Submit MyRect.java and OverlapRectanglesV3.java)</font></td> 
               <td>Completed</td>
               
            </tr>
            <tr>
              <td>20</td>
              <td>Redeem Coupon<br> 
                  (Submit Coupon.java and Redeem.java)</font></td> 
               
              <td>Completed</td> 
            </tr>
            <tr>
              <td>OOP and ArrayList</td> 
              <td>21</td>
              <td>Turning Knobs<br> 
                  (Submit Knob.java and TurnKnobs.java)</font></td> 
               
            	<td>Completed</td>
   
            </tr>
            <!-- Week 5 -->
            <tr>
              <td rowspan="4">9 February,<br>Tuesday</td>
              <td rowspan="2">Inheritance
              </td><td>22</td>
              <td>Circle with Centre<br> 
                  (Submit only CentredCircle.java)</font></td> 
               
              <td>Completed</td>

            </tr>
            <tr>
              <td>23</td>
              <td>Manage Animals<br> 
                  (Submit both Zoo.java and ManageAnimals.java)</font></td> 
               
               <td>Completed</td>

            </tr>
            <tr>
              <td rowspan="2">Exceptions</td> 
              <td>24</td>
              <td>Finding a Root of a Quadratic Equation</td>
               
               <td>Completed</td>

            </tr>
            <tr>
              <td>25</td>
              <td>Finding a Date<br>
                  (Submit TestMyDate.java, MyDate.java 
                                  and InvalidDateException.java)</font></td> 
               <td>Completed</td>

               
            </tr>
            <!-- Week 6 -->
            <tr>
              <td rowspan="5">16 February,<br>Tuesday</td>
              <td rowspan="2">ADT</td> 
              <td>26</td>
              <td>Fraction ADT (Implementation 1) </td> 
               
               
            </tr>
            <tr>
              <td>27</td>
              <td>Fraction ADT (Implementation 2) </td> 
               
               
            </tr>
            <tr>
              <td rowspan="3">Linked List</td> 
              <td>28</td>
              <td>List Reversal<br> 
                  (Submit only MyLinkedList.java)</font></td> 
               
               
            </tr>
            <tr>
              <td>29</td>
              <td>Self-Adjusting List<br> 
                  (Submit only MyLinkedList.java)</font></td> 
               
               
            </tr>
            <tr>
              <td>30</td>
              <td>Sorted Linked List<br>
                  (Submit only MySortedLinkedList.java)</font></td> 
               
               
            </tr>
            <!-- Week 8 -->

            <tr>
             
              <td rowspan="5">10 March,<br>Tuesday</td>
              <td rowspan="5">Stacks and Queues</td>
			  <td>31</td>
              <td>Simple Exercise on Stack<br>
                  (Submit only StackExercise.java)</font></td> 
               
               <td>Completed</td>

            </tr>
            <tr>
              <td>32</td>
              <td>Simple Exercise on Queue<br>
                  (Submit only QueueExercise.java)</font></td> 
               
               <td>Completed</td>

            </tr>
            <tr>
              <td>33</td>
              <td>QuickEat Restaurant</td> 
               
               <td>Completed</td>

            </tr>
            <tr>
              <td>34</td>
              <td>Web Browser History</td> 
               
               <td>Completed</td>

            </tr>
            <tr>
              <td>35</td>
              <td>Simple Parser</td> 
               
               <td>Completed</td>

            </tr>

            <!-- Week 9 -->

            <tr>
             
              <td rowspan="5">17 March,<br>Tuesday</td>
              <td rowspan="5">Recursion</td>
			  <td>36</td>
              <td>North-East Paths</td> 
               
               <td>Completed</td>

            </tr>
            <tr>
              <td>37</td>
              <td>Palindromes</td> 
               
               <td>Completed</td>

            </tr>
            <tr>
              <td>38</td>
              <td>Big Numbers</td> 
               
               
            </tr>
            <tr>
              <td>39</td>
              <td>Jogging in NUS</td> 
               
               
            </tr>
            <tr>
              <td>40</td>
              <td>N Choose K</td> 
               
               
            </tr>

            <!-- Week 10 -->

            <tr>
              <td>41</td>
              <td rowspan="2">24 March,<br>Tuesday</td>
              <td rowspan="2">Analysis of Algorithm</td> 
              <td>Find Pair<br>
                  (Submit only FindPair.java)</font></td> 
               
               
            </tr>
            <tr>
              <td>42</td>
              <td>Maximum Subsequence Sum</td> 
               
               
            </tr>

            <!-- Week 11 -->

            <tr>
              <td>43</td>
              <td rowspan="2">24 March,<br>Tuesday</td>
              <td rowspan="2">OOP and Problem Solving</td> 
              <td>Warcraft</td>
               
               
            </tr>
            <tr>
              <td>44</td>
              <td>School Admin</td> 
               
               
            </tr>

            <!-- Week 12 -->

            <tr>
              <td>45</td>
              <td>31 March,<br>Tuesday</td>
              <td>Sorting</td> 
              <td>Health Screen</td> 
               
               
            </tr>

            <!-- Week 13 -->

            <tr>
              <td>46</td>
              <td rowspan="3">7 April,<br>Tuesday</td>
              <td rowspan="3">Hashing</td> 
              <td>Hashing with Quadratic Probing</td> 
               
               
            </tr>
            <tr>
              <td>47</td>
              <td>Hashing with Double Hashing</td> 
               
               
            </tr>
            <tr>
              <td>48</td>
              <td>Spell-checker Dictionary</td> 
               
               
            </tr>

          </tbody></table>
