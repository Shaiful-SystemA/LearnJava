## Commentaries

Triplet initially seem tough. But I came across a senior who asked the exact same question on [Stack Overflow](http://stackoverflow.com/questions/19648754/maximum-and-minimum-value-for-triplet) last year which helped me understand how I can solve this. 

The key to this solution is to sort the numbers that were entered from input. To ease burden, I created two collections of numbers: positive and negative. 

> I considered zero (0) as a "positive" number. No particular reason, I can put it into the negative collection too.

Do read the SO question and its one and only answer to better understand the logic behind my solution.