## Commentaries

The second sit in lab in CS1020 is said to be the toughest among all 4 sit in labs. The legend is true.

In this lab, the toughest was part was the ability to walk through the algorithm correctly. Your friends, his friends, his friends' friends, my friends,.. all too confusing. 

I admit my code is not in its best form, but at least it was able to pass all the test cases. 

The use of HashSet was not taught in the lecture, but it was mentioned by Prof Tan Sun Teck that Set only allows you to store unique elements (an attribute I took advantage). Otherwise you can always use `.contains()` to check before adding to ensure that there are no duplicates.  